
#CTI-110
#P2HW2 - List
# Gabe Lopez
# 6/28/23 (Late Submission)
#
module1 = float(input("Enter Grade for Module 1: "))
module2 = float(input("Enter Grade for Module 2: "))
module3 = float(input("Enter Grade for Module 3: "))
module4 = float(input("Enter Grade for Module 4: "))
module5 = float(input("Enter Grade for Module 5: "))
module6 = float(input("Enter Grade for Module 6: "))
modulesAll = [module1,module2,module3,module4,module5,module6]
print()
print('-'*12,"Results",'-'*12)
print("Lowest Grade:  ",min(modulesAll))
print("Highest Grade: ",max(modulesAll))
print("Sum of Grades: ",sum(modulesAll))
print("Average:       ",format(sum(modulesAll)/len(modulesAll),'.2f'))
print('-'*31)
